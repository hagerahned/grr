#!/usr/bin/env python
"""This directory contains local site-specific implementations."""

# Local site-specific implementations that have to be imported to be registered
# should be imported in plugins.py.
