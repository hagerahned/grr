#!/usr/bin/env python
"""A module with various utility functions and classes."""
