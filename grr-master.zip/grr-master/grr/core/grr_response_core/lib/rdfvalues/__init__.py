#!/usr/bin/env python
"""AFF4 RDFValue implementations.

This module contains the various RDFValue implementations.
"""
