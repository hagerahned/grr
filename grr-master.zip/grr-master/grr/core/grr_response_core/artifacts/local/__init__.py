#!/usr/bin/env python
"""This directory contains local site-specific artifacts.

All .yaml files in this directory will be automatically loaded by the artifact
library (See the configuration parameter Artifacts.artifact_dirs.
"""
