#!/usr/bin/env python
"""Local contexts.

Put any config.CONFIG.DEFINE_context statements specific to your deployment
in this file.
"""

# pylint: disable=unused-import
from grr_response_core.lib import config_lib
