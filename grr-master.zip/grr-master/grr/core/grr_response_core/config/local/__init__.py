#!/usr/bin/env python
"""This contains all local, site-specific configuration options."""

# pylint: disable=unused-import
from grr_response_core.config.local import contexts
