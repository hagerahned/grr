# Flow Templates: GRR specific 'artifacts'

These 'artifacts' are separate from the main repository because they don't
describe digital forensic artifacts, instead they provide a way to call
pre-defined GRR flows from YAML, the working name for which is 'flow templates'.
