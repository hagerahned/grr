#!/usr/bin/env python
"""Client VFS handlers module root."""
