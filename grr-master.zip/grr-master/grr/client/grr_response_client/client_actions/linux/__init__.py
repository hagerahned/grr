#!/usr/bin/env python
"""A module to load all linux client plugins."""
