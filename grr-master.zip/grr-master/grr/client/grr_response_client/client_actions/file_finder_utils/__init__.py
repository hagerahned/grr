#!/usr/bin/env python
"""Implementation of utilities used in the client-side file-finder."""
