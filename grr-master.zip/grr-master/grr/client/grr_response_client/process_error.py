#!/usr/bin/env python
"""An exception class shared between the OSs."""


class ProcessError(Exception):
  pass
