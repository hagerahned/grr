#!/usr/bin/env python
"""The GRR client agent ."""
